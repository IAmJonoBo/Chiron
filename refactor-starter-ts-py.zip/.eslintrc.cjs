module.exports = {
  root: true,
  parser: "@typescript-eslint/parser",
  parserOptions: { project: ["tsconfig.json"] },
  plugins: ["@typescript-eslint", "sonarjs"],
  extends: [
    "eslint:recommended",
    "plugin:@typescript-eslint/recommended",
    "plugin:sonarjs/recommended"
  ],
  rules: {
    "sonarjs/cognitive-complexity": ["error", 15],
    "complexity": ["error", 15]
  },
  ignorePatterns: ["**/dist/**", "**/build/**", "**/node_modules/**"]
};
