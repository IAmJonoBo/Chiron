# TS + Python Refactor Starter (drop-in)

This kit gives you:
- **Hotspot analysis** for Python: `scripts/hotspots/git_churn.sh` then `scripts/hotspots/hotspots_py.py`
- **Codemods**: TypeScript (jscodeshift + ts-morph) and Python (LibCST)
- **Quality gates**: ESLint + sonarjs cognitive complexity; Ruff/Black/mypy; Radon/Xenon; jscpd duplication; Bandit & pip-audit
- **Mutation testing**: StrykerJS (TS) and mutmut (Py)
- **CI**: GitHub Actions workflow with soft-fail steps you can harden later.

## Run book
1. **Install**: `pnpm i` (or `npm i`) and `pip install -r requirements-dev.txt`
2. **Hotspots (Py)**: `scripts/hotspots/git_churn.sh` then `scripts/hotspots/hotspots_py.py`
3. **Refactor safely**: add characterisation & property tests, run codemods, submit small PRs.
4. **Harden gates**: remove `|| true` from CI steps you want to enforce.

## References
- Ruff: https://docs.astral.sh/ruff/ ; Black: https://black.readthedocs.io/ ; mypy: https://mypy.readthedocs.io/ ; pip-audit: https://github.com/pypa/pip-audit
- ESLint complexity rule: https://eslint.org/docs/latest/rules/complexity ; sonarjs plugin: https://github.com/SonarSource/eslint-plugin-sonarjs
- jscodeshift: https://jscodeshift.com/ ; ts-morph: https://ts-morph.com/
- LibCST: https://libcst.readthedocs.io/ ; Rope: https://rope.readthedocs.io/
- Radon/Xenon: https://radon.readthedocs.io/ ; https://xenon.readthedocs.io/
- StrykerJS: https://stryker-mutator.io/docs/stryker-js/introduction/ ; mutmut: https://mutmut.readthedocs.io/
- jscpd: https://github.com/kucherenko/jscpd ; Difftastic: https://difftastic.wilfred.me.uk/
