import { API, FileInfo, JSCodeshift } from "jscodeshift";

const OLD = "old-lib";
const NEW = "new-lib";

export default function transform(file: FileInfo, api: API) {
  const j: JSCodeshift = api.jscodeshift;
  const root = j(file.source);
  root.find(j.ImportDeclaration, { source: { value: OLD } })
      .forEach(p => p.node.source.value = NEW);
  return root.toSource();
}
