import { Project } from "ts-morph";

const OLD = "OldThing";
const NEW = "NewThing";

async function main() {
  const project = new Project({ tsConfigFilePath: "tsconfig.json" });
  const files = project.getSourceFiles("src/**/*.ts");
  for (const sf of files) {
    for (const cls of sf.getClasses()) {
      if (cls.getName() === OLD) cls.rename(NEW);
    }
  }
  await project.save();
}
main().catch(err => { console.error(err); process.exit(1); });
