#!/usr/bin/env bash
set -euo pipefail
since="${1:-12 months ago}"
out="scripts/hotspots/churn.txt"
git log --since="$since" --name-only --pretty=format:     | awk 'NF' | sort | uniq -c | sort -nr > "$out"
echo "Wrote $out"
