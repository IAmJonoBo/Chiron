#!/usr/bin/env python3
import sys
import pathlib
import libcst as cst
from libcst import matchers as m

OLD = "foo"
NEW = "bar"

class RenameCall(cst.CSTTransformer):
    def leave_Call(self, original: cst.Call, updated: cst.Call) -> cst.Call:
        if m.matches(original.func, m.Name(value=OLD)):
            return updated.with_changes(func=cst.Name(NEW))
        return updated

def run(path: pathlib.Path) -> None:
    src = path.read_text(encoding="utf-8")
    mod = cst.parse_module(src)
    out = mod.visit(RenameCall())
    path.write_text(out.code, encoding="utf-8")

if __name__ == "__main__":
    for arg in sys.argv[1:]:
        p = pathlib.Path(arg)
        if p.is_file() and p.suffix == ".py":
            run(p)
